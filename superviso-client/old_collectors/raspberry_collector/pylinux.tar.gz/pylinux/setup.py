# Setup.py for image_builder
from distutils.core import setup

setup(name='pylinux',
      version='0.1',
      description='Python interface to Linux System Information',
      author='Amit Saha',
      author_email='amitsaha.in@gmail.com',
      packages=['pylinux']
     )
