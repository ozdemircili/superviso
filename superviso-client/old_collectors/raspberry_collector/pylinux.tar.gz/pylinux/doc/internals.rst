Implementation details
======================
